# connectUS Live

Transcripción + traducción EN↔ES en tiempo real para intérpretes. Captura el audio de la pestaña de la llamada (no tu micrófono), traduce y expande siglas médicas/de seguros. No guarda nada en disco.

## Correr en tu computadora
1. Instala Node.js 18 o superior.
2. `npm install`
3. Copia `.env.example` a `.env` y pon tus claves **nuevas** (Deepgram y OpenAI).
4. `npm start`
5. Abre http://localhost:8080 en Chrome o Edge, pulsa **Capturar audio** y elige la pestaña de la llamada marcando **Compartir audio de la pestaña**.

## Atajos
- Barra espaciadora: pausar / reanudar la vista.
- Botones S / M / L / XL: tamaño de letra.

## Desplegar
Necesita un servidor que mantenga WebSockets (Render, Railway, Fly.io). Define las variables en el panel de la plataforma. Netlify no sirve para este servidor. En producción la página usa `wss://` automáticamente.
