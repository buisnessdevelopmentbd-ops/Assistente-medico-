// server.js - Backend en memoria volátil (no guarda audio ni texto)
require('dotenv').config();
const path = require('path');
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const { createClient, LiveTranscriptionEvents } = require('@deepgram/sdk');

// Las claves se leen SOLO desde variables de entorno
const missing = ['DEEPGRAM_API_KEY', 'OPENAI_API_KEY'].filter((k) => !process.env[k]);
if (missing.length) {
  console.error(`Faltan variables de entorno: ${missing.join(', ')}. Copia .env.example a .env y complétalo.`);
  process.exit(1);
}
const PORT = process.env.PORT || 8080;

const app = express();
app.use(cors());
app.use(express.static(path.join(__dirname, 'public'))); // sirve la interfaz en el mismo origen
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const deepgram = createClient(process.env.DEEPGRAM_API_KEY);

async function translateSegment(text, lang) {
  const target = lang === 'es' ? 'English' : 'Spanish';
  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        temperature: 0.1,
        messages: [
          {
            role: 'system',
            content: `You are a real-time medical and health-insurance translator. Translate into ${target}.
RULES:
1. Keep ALL numbers as digits (120, 2026, 50 mg).
2. Remove filler words (um, uh, like, este, o sea, pues).
3. Keep medical/insurance acronyms (EOB, PCP, MRI, deductible) unchanged.
4. NEVER translate street names, addresses, or proper names (e.g. "Sunset Boulevard" stays as is).
5. Return ONLY the clean translation, no notes.`
          },
          { role: 'user', content: text }
        ]
      })
    });
    const data = await res.json();
    return data.choices[0].message.content.trim();
  } catch (err) {
    console.error('Error en traducción:', err.message);
    return '[Error de traducción]';
  }
}

wss.on('connection', (client) => {
  console.log('Sesión iniciada (memoria volátil)');

  const dg = deepgram.listen.live({
    model: 'nova-2',
    language: 'multi', // detección automática EN/ES
    smart_format: true,
    numerals: true,
    filler_words: false,
    punctuate: true,
    interim_results: true,
    endpointing: 1200,
    utterance_end_ms: 1500,
    vad_events: true
  });

  const keepAlive = setInterval(() => {
    try { dg.keepAlive(); } catch (_) {}
  }, 8000);

  dg.on(LiveTranscriptionEvents.Open, () => {
    client.send(JSON.stringify({ type: 'STATUS', status: 'CONNECTED' }));

    dg.on(LiveTranscriptionEvents.Transcript, async (data) => {
      const alt = data.channel?.alternatives?.[0];
      if (!alt || !alt.transcript) return;

      // Con language=multi, el idioma llega en alternatives[0].languages
      const lang = (alt.languages?.[0] || data.channel?.detected_language || 'en').slice(0, 2);

      if (!data.is_final) {
        client.send(JSON.stringify({ type: 'INTERIM', text: alt.transcript, lang }));
        return;
      }
      const translated = await translateSegment(alt.transcript, lang);
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({
          type: 'FINAL',
          original: alt.transcript,
          translated,
          lang,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        }));
      }
    });

    dg.on(LiveTranscriptionEvents.Error, (e) => console.error('Deepgram error:', e?.message || e));
  });

  client.on('message', (chunk) => {
    if (dg.getReadyState() === 1) dg.send(chunk);
  });

  client.on('close', () => {
    clearInterval(keepAlive);
    dg.requestClose?.();
    console.log('Sesión cerrada. Nada se guardó.');
  });
});

server.listen(PORT, () => console.log(`connectUS Live en http://localhost:${PORT}`));
